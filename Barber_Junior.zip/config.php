<?php

$hostname = "us-cdbr-east-06.cleardb.net";
$usuario = "b5cb88ee843bc5";
$senha = "daa1987b";
$bancodedados = "heroku_0619edf52a077e1";

$conexao = new mysqli($hostname, $usuario, $senha, $bancodedados);


    